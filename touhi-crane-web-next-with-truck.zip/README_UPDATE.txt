GitHubの index.html と styles.css をこの2ファイルで上書き。
車両写真は rafter.jpg / allterrain.jpg / truck.jpg の名前で同じ場所に置けば自動表示。
写真がない枠は PHOTO 表示のままです。
